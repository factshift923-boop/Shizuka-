# Keep Shizuka's public API surface stable across ProGuard/R8 optimization.
-keep class com.shizuka.assistant.** { *; }

# OkHttp / Okio platform detection uses reflection on these — keep as-is.
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
