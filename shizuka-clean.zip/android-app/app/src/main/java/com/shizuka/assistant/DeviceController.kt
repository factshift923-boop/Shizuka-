package com.shizuka.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.shizuka.assistant.ShizukaAccessibilityService

/**
 * Handles every device-level automation action that goes beyond simple app
 * launching: text injection into focused fields, alarm creation, phone calls,
 * and web searches. All actions use only official Android Intent/Accessibility
 * APIs — zero third-party SDKs, zero data sent outside the device.
 */
object DeviceController {

    // ─── TYPE_TEXT ────────────────────────────────────────────────────────

    /**
     * Injects [text] into the currently focused editable field using the
     * Accessibility ACTION_SET_TEXT API. Falls back to a clipboard-paste
     * strategy if no focused editable node is found.
     *
     * Requires the Accessibility Service to be connected.
     */
    fun typeTextIntoFocusedField(service: ShizukaAccessibilityService, text: String): Boolean {
        if (text.isBlank()) {
            Log.w(Constants.LOG_TAG, "DeviceController.typeText: empty text, nothing to do")
            return false
        }

        val root = service.rootInActiveWindow ?: run {
            Log.e(Constants.LOG_TAG, "DeviceController.typeText: rootInActiveWindow is null")
            return false
        }

        // 1. Try the currently input-focused node first
        val focusedNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focusedNode != null && focusedNode.isEditable) {
            val success = setTextOnNode(focusedNode, text)
            focusedNode.recycle()
            root.recycle()
            if (success) return true
        } else {
            focusedNode?.recycle()
        }

        // 2. Fallback: find the first visible editable field on screen
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        collectEditableNodes(root, editableNodes)
        root.recycle()

        val firstEditable = editableNodes.firstOrNull()

        return if (firstEditable != null) {
            // Give it input focus, then inject
            firstEditable.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
            firstEditable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val success = setTextOnNode(firstEditable, text)
            editableNodes.forEach { it.recycle() }
            success
        } else {
            editableNodes.forEach { it.recycle() }
            Log.w(Constants.LOG_TAG, "DeviceController.typeText: no editable field found on screen")
            false
        }
    }

    private fun setTextOnNode(node: AccessibilityNodeInfo, text: String): Boolean {
        return try {
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text,
                )
            }
            val result = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            Log.i(Constants.LOG_TAG, "DeviceController.typeText: ACTION_SET_TEXT result=$result text='${text.take(40)}'")
            result
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "DeviceController.typeText: ACTION_SET_TEXT threw", e)
            false
        }
    }

    private fun collectEditableNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isEditable && node.isVisibleToUser) {
            out.add(AccessibilityNodeInfo.obtain(node))
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectEditableNodes(child, out)
            // Don't recycle child here — getChild returns a new copy; we need it while traversing
            if (!child.isEditable) child.recycle()
        }
    }

    // ─── SET_ALARM ────────────────────────────────────────────────────────

    /**
     * Sets an alarm using the system's AlarmClock app. [timeTarget] must be
     * in "HH:MM" 24-hour format (as the backend guarantees). [label] is
     * optional and may be an empty string.
     */
    fun setAlarm(context: Context, timeTarget: String, label: String): Boolean {
        val parsed = parseAlarmTime(timeTarget) ?: run {
            Log.w(Constants.LOG_TAG, "DeviceController.setAlarm: could not parse time '$timeTarget'")
            return false
        }

        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, parsed.first)
                putExtra(AlarmClock.EXTRA_MINUTES, parsed.second)
                if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false) // Show the clock app for confirmation
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.i(Constants.LOG_TAG, "DeviceController.setAlarm: ${parsed.first}:${parsed.second.toString().padStart(2, '0')} label='$label'")
            true
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "DeviceController.setAlarm: failed to launch alarm intent", e)
            false
        }
    }

    /**
     * Parses a time string in "HH:MM" format (guaranteed by the backend
     * contract) into (hour, minute). Also handles bare hour integers and
     * common loose formats as a safety net.
     */
    fun parseAlarmTime(timeStr: String): Pair<Int, Int>? {
        val normalized = timeStr.trim()

        // Primary: HH:MM (guaranteed by the backend)
        val colonMatch = Regex("^(\\d{1,2}):(\\d{2})$").find(normalized)
        if (colonMatch != null) {
            val h = colonMatch.groupValues[1].toIntOrNull() ?: return null
            val m = colonMatch.groupValues[2].toIntOrNull() ?: return null
            if (h in 0..23 && m in 0..59) return Pair(h, m)
        }

        // Safety net: bare hour digit with optional AM/PM context
        val numMatch = Regex("(\\d{1,2})").find(normalized)
        if (numMatch != null) {
            var h = numMatch.groupValues[1].toIntOrNull() ?: return null
            val isPM = normalized.contains(Regex("(?i)pm|evening|sham|raat"))
            val isAM = normalized.contains(Regex("(?i)am|morning|subah"))
            if (isPM && h in 1..11) h += 12
            if (isAM && h == 12) h = 0
            if (h in 0..23) return Pair(h, 0)
        }

        return null
    }

    // ─── CALL ─────────────────────────────────────────────────────────────

    /**
     * Opens the dialler pre-filled with [target] (contact name or number).
     * Uses ACTION_DIAL (no special permission) so the user confirms before
     * the call is placed. If a numeric target is given, dials it directly.
     */
    fun makeCall(context: Context, target: String): Boolean {
        if (target.isBlank()) {
            Log.w(Constants.LOG_TAG, "DeviceController.makeCall: empty target")
            return false
        }

        return try {
            val digitsOnly = target.filter { it.isDigit() || it == '+' }
            val isNumeric = digitsOnly.length >= 5

            val intent = if (isNumeric) {
                // Phone number — pre-fill the dialler
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digitsOnly")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                // Contact name — open the contacts list filtered to matching names.
                // ACTION_VIEW on a CONTENT_FILTER_URI opens the Contacts app showing
                // only entries that match the query string, so the user can tap ▶ to
                // place the call without us needing READ_CONTACTS permission.
                val filterUri = android.provider.ContactsContract.Contacts.CONTENT_FILTER_URI
                    .buildUpon()
                    .appendPath(Uri.encode(target))
                    .build()
                Intent(Intent.ACTION_VIEW, filterUri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }

            context.startActivity(intent)
            Log.i(Constants.LOG_TAG, "DeviceController.makeCall: target='$target' isNumeric=$isNumeric")
            true
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "DeviceController.makeCall: failed", e)
            false
        }
    }

    // ─── SEARCH ───────────────────────────────────────────────────────────

    /**
     * Opens a Google web search for [query] in the default browser. Falls
     * back to the system ACTION_WEB_SEARCH intent if the URI approach fails.
     */
    fun searchWeb(context: Context, query: String): Boolean {
        if (query.isBlank()) {
            Log.w(Constants.LOG_TAG, "DeviceController.searchWeb: empty query")
            return false
        }

        return try {
            val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Log.i(Constants.LOG_TAG, "DeviceController.searchWeb: query='${query.take(60)}'")
            true
        } catch (e1: Exception) {
            Log.w(Constants.LOG_TAG, "DeviceController.searchWeb: URI approach failed, trying ACTION_WEB_SEARCH", e1)
            try {
                val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } catch (e2: Exception) {
                Log.e(Constants.LOG_TAG, "DeviceController.searchWeb: both approaches failed", e2)
                false
            }
        }
    }
}
