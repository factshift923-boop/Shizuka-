package com.shizuka.assistant

import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.materialswitch.MaterialSwitch

/**
 * Shizuka main dashboard.
 *
 * UI: Anime avatar + pulsing neon orb + three permission toggles
 * + top-right gear icon → [SettingsActivity].
 *
 * The orb is driven by [ObjectAnimator]:
 *  • Idle   — slow ambient pulse (scale 1.0 ↔ 1.06, α 0.70 ↔ 1.0)
 *  • Active — fast energetic pulse (scale 1.0 ↔ 1.18, α 0.80 ↔ 1.0)
 *    swapped to the neon gradient drawable while listening.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private lateinit var switchAccessibility: MaterialSwitch
    private lateinit var switchMic: MaterialSwitch
    private lateinit var switchOverlay: MaterialSwitch
    private lateinit var statusPill: TextView
    private lateinit var viewOrb: ImageView
    private lateinit var textOrbLabel: TextView

    private var orbAnimator: AnimatorSet? = null

    // ─── Permission launchers ────────────────────────────────────────────

    private val requestRecordAudio = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) promptBatteryOptimizationExemption()
        else Toast.makeText(this, "Mic access needed so Shizuka can hear you.", Toast.LENGTH_LONG).show()
        refreshSwitchStates()
    }

    private val overlaySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { refreshSwitchStates() }

    private val accessibilitySettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { refreshSwitchStates() }

    private val batteryOptimizationLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { refreshSwitchStates() }

    private val settingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()) { refreshSwitchStates() }

    // ─── Lifecycle ───────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

        viewOrb        = findViewById(R.id.viewOrb)
        textOrbLabel   = findViewById(R.id.textOrbLabel)
        statusPill     = findViewById(R.id.textStatusPill)
        switchAccessibility = findViewById(R.id.switchAccessibility)
        switchMic           = findViewById(R.id.switchMic)
        switchOverlay        = findViewById(R.id.switchOverlay)

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            settingsLauncher.launch(Intent(this, SettingsActivity::class.java))
        }

        setupAccessibilitySwitch()
        setupMicSwitch()
        setupOverlaySwitch()
        startOrbAmbientPulse()
    }

    override fun onResume() {
        super.onResume()
        refreshSwitchStates()
        ApiClient.configure(prefs)
    }

    override fun onDestroy() {
        orbAnimator?.cancel()
        super.onDestroy()
    }

    // ─── Orb animation ───────────────────────────────────────────────────

    /**
     * Slow ambient pulse — always running in the background to show
     * Shizuka is alive. The orb swaps its drawable and speeds up when the
     * accessibility service signals active listening.
     */
    private fun startOrbAmbientPulse() {
        orbAnimator?.cancel()

        val scaleX = ObjectAnimator.ofFloat(viewOrb, "scaleX", 1.0f, 1.07f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode  = ValueAnimator.REVERSE
        }
        val scaleY = ObjectAnimator.ofFloat(viewOrb, "scaleY", 1.0f, 1.07f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode  = ValueAnimator.REVERSE
        }
        val alpha = ObjectAnimator.ofFloat(viewOrb, "alpha", 0.70f, 1.0f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode  = ValueAnimator.REVERSE
        }

        orbAnimator = AnimatorSet().apply {
            playTogether(scaleX, scaleY, alpha)
            start()
        }
    }

    /** Switches the orb to the active neon gradient and speeds up the pulse. */
    fun setOrbActive(active: Boolean) {
        orbAnimator?.cancel()

        viewOrb.setImageResource(
            if (active) R.drawable.bg_orb_gradient else R.drawable.bg_orb_idle,
        )
        textOrbLabel.text = getString(
            if (active) R.string.orb_listening else R.string.orb_idle,
        )

        val scale  = if (active) 1.16f else 1.07f
        val dur    = if (active) 700L  else 1800L
        val alphaStart = if (active) 0.80f else 0.70f

        val scaleX = ObjectAnimator.ofFloat(viewOrb, "scaleX", 1.0f, scale).apply {
            duration = dur; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }
        val scaleY = ObjectAnimator.ofFloat(viewOrb, "scaleY", 1.0f, scale).apply {
            duration = dur; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }
        val alpha = ObjectAnimator.ofFloat(viewOrb, "alpha", alphaStart, 1.0f).apply {
            duration = dur; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
        }

        orbAnimator = AnimatorSet().apply { playTogether(scaleX, scaleY, alpha); start() }
    }

    // ─── Permission switches ─────────────────────────────────────────────

    private fun setupAccessibilitySwitch() {
        switchAccessibility.setOnCheckedChangeListener { view, isChecked ->
            if (isChecked && !isAccessibilityServiceEnabled()) {
                view.isChecked = false
                openAccessibilitySettings()
                return@setOnCheckedChangeListener
            }
            prefs.edit().putBoolean(Constants.PREF_ACCESSIBILITY_ENABLED, isChecked).apply()
            if (!isChecked && isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Also disable Shizuka in Accessibility settings to fully stop the service.", Toast.LENGTH_LONG).show()
                openAccessibilitySettings()
            }
            updateStatusPill()
        }
    }

    private fun setupMicSwitch() {
        switchMic.setOnCheckedChangeListener { view, isChecked ->
            if (isChecked) {
                if (!hasRecordAudioPermission()) {
                    requestRecordAudio.launch(android.Manifest.permission.RECORD_AUDIO)
                } else if (!isIgnoringBatteryOptimizations()) {
                    promptBatteryOptimizationExemption()
                } else {
                    prefs.edit().putBoolean(Constants.PREF_MIC_ENABLED, true).apply()
                }
            } else {
                prefs.edit().putBoolean(Constants.PREF_MIC_ENABLED, false).apply()
                view.isChecked = false
            }
            updateStatusPill()
        }
    }

    private fun setupOverlaySwitch() {
        switchOverlay.setOnCheckedChangeListener { view, isChecked ->
            if (isChecked && !hasOverlayPermission()) {
                view.isChecked = false
                openOverlaySettings()
                return@setOnCheckedChangeListener
            }
            prefs.edit().putBoolean(Constants.PREF_OVERLAY_ENABLED, isChecked).apply()
            updateStatusPill()
        }
    }

    // ─── State refresh ───────────────────────────────────────────────────

    private fun refreshSwitchStates() {
        val accOn     = isAccessibilityServiceEnabled()
        val micOn     = hasRecordAudioPermission() && isIgnoringBatteryOptimizations()
        val overlayOn = hasOverlayPermission()

        // Silence listeners before programmatic state change
        switchAccessibility.setOnCheckedChangeListener(null)
        switchMic.setOnCheckedChangeListener(null)
        switchOverlay.setOnCheckedChangeListener(null)

        switchAccessibility.isChecked = accOn
        switchMic.isChecked           = micOn
        switchOverlay.isChecked       = overlayOn

        prefs.edit()
            .putBoolean(Constants.PREF_ACCESSIBILITY_ENABLED, accOn)
            .putBoolean(Constants.PREF_MIC_ENABLED,           micOn)
            .putBoolean(Constants.PREF_OVERLAY_ENABLED,       overlayOn)
            .apply()

        setupAccessibilitySwitch()
        setupMicSwitch()
        setupOverlaySwitch()
        updateStatusPill()
    }

    private fun updateStatusPill() {
        val allReady = switchAccessibility.isChecked && switchMic.isChecked && switchOverlay.isChecked
        statusPill.text = getString(if (allReady) R.string.status_all_ready else R.string.status_needs_setup)
        statusPill.setBackgroundResource(if (allReady) R.drawable.bg_status_pill_ready else R.drawable.bg_status_pill_warning)
    }

    // ─── Permission helpers ──────────────────────────────────────────────

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                   it.resolveInfo.serviceInfo.name == ShizukaAccessibilityService::class.java.name }
    }

    private fun hasRecordAudioPermission() =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun isIgnoringBatteryOptimizations() =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun hasOverlayPermission() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true

    private fun openAccessibilitySettings() =
        accessibilitySettingsLauncher.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    private fun openOverlaySettings() =
        overlaySettingsLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    @Suppress("BatteryLife")
    private fun promptBatteryOptimizationExemption() {
        if (isIgnoringBatteryOptimizations()) {
            prefs.edit().putBoolean(Constants.PREF_MIC_ENABLED, true).apply()
            return
        }
        batteryOptimizationLauncher.launch(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
        )
    }
}
