package com.shizuka.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log

/**
 * Builds and fires the native WhatsApp deep-link intent for the backend's
 * `"WHATSAPP"` action, preloading the compose box with the given message.
 */
object WhatsAppLauncher {

    /** Matches strings that look like a phone number (digits, plus, spaces, dashes). */
    private val PHONE_NUMBER_REGEX = Regex("^[+\\d][\\d\\s-]{5,}$")

    /**
     * Sends [message] via WhatsApp. If [rawTarget] looks like a phone
     * number, deep-links directly into a chat with that number
     * (`phone=` query param); otherwise falls back to the generic
     * `text=` compose intent, letting the user pick the contact
     * themselves inside WhatsApp. Returns `true` if the intent was
     * successfully dispatched.
     */
    fun send(context: Context, rawTarget: String, message: String): Boolean {
        return try {
            val trimmedTarget = rawTarget.trim()
            val encodedMessage = Uri.encode(message)

            val uri = if (trimmedTarget.isNotEmpty() && PHONE_NUMBER_REGEX.matches(trimmedTarget)) {
                val digitsOnly = trimmedTarget.filter { it.isDigit() || it == '+' }
                Uri.parse("https://api.whatsapp.com/send?phone=$digitsOnly&text=$encodedMessage")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedMessage")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.whatsapp")
            }

            if (intent.resolveActivity(context.packageManager) == null) {
                // WhatsApp isn't installed under the standard package name;
                // fall back to letting the OS resolve any handler for the
                // deep link (e.g. WhatsApp Business, or a browser landing
                // page as a last resort).
                intent.setPackage(null)
            }

            context.startActivity(intent)
            true
        } catch (error: Exception) {
            Log.e(Constants.LOG_TAG, "Failed to launch WhatsApp intent for target=$rawTarget", error)
            false
        }
    }
}
