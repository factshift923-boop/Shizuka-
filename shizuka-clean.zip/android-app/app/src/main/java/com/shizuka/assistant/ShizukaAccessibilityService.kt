package com.shizuka.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import okhttp3.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Shizuka's always-on background engine — complete rewrite (v2).
 *
 * What's new in this version:
 *  • **Atomic deduplication** — [isProcessingTranscript] ensures every
 *    spoken phrase is handled exactly once, eliminating the double-fire bug
 *    where the same utterance triggered multiple backend calls.
 *  • **Silent audio engine** — recognition-start beeps are eliminated by
 *    temporarily muting the notification + ring audio streams immediately
 *    before [SpeechRecognizer.startListening] and restoring them after
 *    [BEEP_MUTE_DURATION_MS]. Volume levels are always restored correctly,
 *    including in error/teardown paths.
 *  • **Expanded action execution** — handles all seven backend actions:
 *    OPEN, WHATSAPP, CHAT, TYPE_TEXT, SET_ALARM, CALL, SEARCH.
 *  • **TTS echo gate** — mic is paused for the full duration of TTS
 *    playback ([isSpeaking] flag) so Shizuka never re-processes her own voice.
 *  • **Full teardown on task removal** — mic, network, wake lock, and
 *    foreground notification are all released the instant the user swipes
 *    Shizuka from Recents (privacy-critical for an always-on mic app).
 *  • **Language & user name forwarded to backend** — reads from
 *    SharedPreferences on every cycle so new settings take effect without
 *    a service restart.
 */
class ShizukaAccessibilityService : AccessibilityService() {

    // ─── Core state ───────────────────────────────────────────────────────

    private var speechRecognizer: SpeechRecognizer? = null
    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    /** Guards against double-processing the same spoken phrase. Set in
     *  [onResults], cleared only after TTS playback fully finishes. */
    private val isProcessingTranscript = AtomicBoolean(false)

    /** True while Shizuka's TTS reply is playing — keeps the mic closed. */
    @Volatile private var isSpeaking = false

    /** Prevents teardown from running twice. */
    private var isServiceTornDown = false

    private var lastVolumeKeyTimestamp = 0L
    private var isListeningCycleActive = false

    // ─── Volume mute tracking (silent engine) ─────────────────────────────

    private var savedNotificationVolume = -1
    private var savedRingVolume         = -1
    private var isAudioMuted            = false

    // ─── SharedPreferences ────────────────────────────────────────────────

    private lateinit var prefs: SharedPreferences

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Constants.PREF_ACCESSIBILITY_ENABLED,
            Constants.PREF_MIC_ENABLED -> {
                if (isBackgroundListeningEnabled()) startContinuousListening()
                else stopListeningCycle()
            }
            Constants.PREF_BACKEND_URL,
            Constants.PREF_LANGUAGE,
            Constants.PREF_USER_NAME,
            Constants.PREF_API_KEY -> {
                ApiClient.configure(prefs)
            }
        }
    }

    // ─── AccessibilityService lifecycle ───────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(Constants.LOG_TAG, "ShizukaAccessibilityService connected")

        isServiceTornDown = false
        prefs = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        // Configure the HTTP client with the latest saved settings
        ApiClient.configure(prefs)

        // Enable key-event filtering + window-content retrieval at runtime
        // (some OEM accessibility menus strip static XML flags)
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.flags = info.flags or
            AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
            AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
        info.notificationTimeout = 100
        serviceInfo = info

        acquireWakeLock()
        startForegroundListeningNotification()

        if (isBackgroundListeningEnabled()) {
            startContinuousListening()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Voice pipeline only — no UI event side-effects.
    }

    override fun onInterrupt() {
        Log.w(Constants.LOG_TAG, "ShizukaAccessibilityService interrupted by system")
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.i(Constants.LOG_TAG, "Task removed — executing full teardown for privacy")
        teardownEverything()
    }

    override fun onDestroy() {
        teardownEverything()
        super.onDestroy()
    }

    // ─── Teardown ─────────────────────────────────────────────────────────

    /**
     * Full, idempotent teardown. Always restores audio before exiting so
     * the user's phone is never left silenced after a crash.
     */
    private fun teardownEverything() {
        if (isServiceTornDown) return
        isServiceTornDown = true

        mainHandler.removeCallbacksAndMessages(null)

        // Always restore audio first — even in crash paths
        restoreAudioStreams()

        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Error destroying SpeechRecognizer", e)
        }
        speechRecognizer = null
        isListeningCycleActive = false

        try {
            mediaPlayer?.let { if (it.isPlaying) it.stop(); it.release() }
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Error releasing MediaPlayer", e)
        }
        mediaPlayer = null

        ApiClient.cancelAllRequests()

        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null

        try {
            if (::prefs.isInitialized) {
                prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
            }
        } catch (_: Exception) {}

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ─── Hardware volume hotkey ────────────────────────────────────────────

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false

        val isVolumeKey = event.keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
                          event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (!isVolumeKey) return false

        val now = System.currentTimeMillis()
        val elapsed = now - lastVolumeKeyTimestamp

        if (elapsed in 1 until Constants.DOUBLE_PRESS_WINDOW_MS) {
            lastVolumeKeyTimestamp = 0L
            Log.i(Constants.LOG_TAG, "Double volume-press detected — waking Shizuka")
            mainHandler.post { beginRecognitionCycle() }
        } else {
            lastVolumeKeyTimestamp = now
        }

        // Return false so normal volume adjustment still works
        return false
    }

    // ─── Continuous listening pipeline ────────────────────────────────────

    private fun isBackgroundListeningEnabled(): Boolean {
        val accOn = prefs.getBoolean(Constants.PREF_ACCESSIBILITY_ENABLED, false)
        val micOn = prefs.getBoolean(Constants.PREF_MIC_ENABLED, false)
        return accOn && micOn && hasRecordAudioPermission()
    }

    private fun hasRecordAudioPermission() =
        checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun startContinuousListening() {
        if (isListeningCycleActive) return
        mainHandler.post { beginRecognitionCycle() }
    }

    private fun stopListeningCycle() {
        mainHandler.post {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            isListeningCycleActive = false
        }
    }

    private fun beginRecognitionCycle() {
        if (isServiceTornDown || !hasRecordAudioPermission()) return
        if (isSpeaking) return   // Never listen during TTS playback
        if (isProcessingTranscript.get()) return   // Never start a new cycle mid-processing

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(Constants.LOG_TAG, "Speech recognition not available on this device")
            return
        }

        isListeningCycleActive = true

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(buildRecognitionListener())
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            // Suppress the recognition UI — Shizuka handles all feedback herself
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }

        try {
            // ── SILENT ENGINE: mute notification/ring beeps before startListening ──
            muteAudioStreams()
            speechRecognizer?.startListening(intent)
            // Restore audio after the recognition service has had enough time
            // to start (and produce its beep, now suppressed)
            mainHandler.postDelayed({ restoreAudioStreams() }, Constants.BEEP_MUTE_DURATION_MS)
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Failed to start SpeechRecognizer", e)
            restoreAudioStreams()
            isListeningCycleActive = false
        }
    }

    // ─── Silent audio engine helpers ──────────────────────────────────────

    /**
     * Saves current notification + ring volumes, then sets them to 0.
     * Called immediately before [SpeechRecognizer.startListening] to
     * suppress the recognition-start beep tone. Always matched by
     * [restoreAudioStreams].
     */
    private fun muteAudioStreams() {
        val am = audioManager ?: return
        if (isAudioMuted) return   // Already muted — don't double-save

        try {
            savedNotificationVolume = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
            savedRingVolume         = am.getStreamVolume(AudioManager.STREAM_RING)

            am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            am.setStreamVolume(AudioManager.STREAM_RING, 0, 0)
            isAudioMuted = true
        } catch (e: Exception) {
            Log.w(Constants.LOG_TAG, "muteAudioStreams: could not mute streams", e)
        }
    }

    /**
     * Restores notification + ring volumes to the values saved by
     * [muteAudioStreams]. Safe to call multiple times — idempotent.
     */
    private fun restoreAudioStreams() {
        val am = audioManager ?: return
        if (!isAudioMuted) return

        try {
            if (savedNotificationVolume >= 0) {
                am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotificationVolume, 0)
            }
            if (savedRingVolume >= 0) {
                am.setStreamVolume(AudioManager.STREAM_RING, savedRingVolume, 0)
            }
        } catch (e: Exception) {
            Log.w(Constants.LOG_TAG, "restoreAudioStreams: could not restore streams", e)
        } finally {
            isAudioMuted = false
            savedNotificationVolume = -1
            savedRingVolume         = -1
        }
    }

    // ─── Recognition listener ─────────────────────────────────────────────

    private fun buildRecognitionListener(): RecognitionListener = object : RecognitionListener {

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            // Restore audio the moment actual speech begins —
            // the beep window has definitely passed by now.
            restoreAudioStreams()
        }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            restoreAudioStreams()
            isListeningCycleActive = false
            Log.w(Constants.LOG_TAG, "SpeechRecognizer error: $error")
            scheduleListeningRestartIfEnabled()
        }

        override fun onResults(results: Bundle?) {
            restoreAudioStreams()
            isListeningCycleActive = false

            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val rawTranscript = matches?.firstOrNull().orEmpty()

            if (rawTranscript.isBlank()) {
                scheduleListeningRestartIfEnabled()
                return
            }

            // ── DEDUPLICATION GATE ──
            // Atomically claim processing ownership. If another cycle has
            // already claimed it (shouldn't happen, but guards against race
            // conditions on fast devices), silently discard this result.
            if (!isProcessingTranscript.compareAndSet(false, true)) {
                Log.w(Constants.LOG_TAG, "Duplicate transcript dropped: '$rawTranscript'")
                scheduleListeningRestartIfEnabled()
                return
            }

            handleRawTranscript(rawTranscript)
            // NOTE: do NOT call scheduleListeningRestartIfEnabled() here.
            // The restart is scheduled by onSpeechPlaybackFinished() after
            // TTS completes, keeping the pipeline sequential.
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun scheduleListeningRestartIfEnabled() {
        if (isServiceTornDown || !isBackgroundListeningEnabled() || isSpeaking) return
        mainHandler.postDelayed({ beginRecognitionCycle() }, Constants.LISTEN_RESTART_DELAY_MS)
    }

    // ─── Transcript → Backend → Action pipeline ───────────────────────────

    private fun handleRawTranscript(rawTranscript: String) {
        val cleaned     = VoiceProcessor.cleanTranscript(rawTranscript)
        val commandText = VoiceProcessor.stripWakeWord(cleaned).ifBlank { cleaned }

        if (commandText.isBlank()) {
            isProcessingTranscript.set(false)
            scheduleListeningRestartIfEnabled()
            return
        }

        Log.i(Constants.LOG_TAG, "Transcript: \"$rawTranscript\" → \"$commandText\"")

        ApiClient.sendChatMessage(
            message   = commandText,
            onSuccess = { intent ->
                mainHandler.post {
                    handleShizukaIntent(intent)
                }
            },
            onError = { error ->
                Log.e(Constants.LOG_TAG, "Chat request failed", error)
                isProcessingTranscript.set(false)
                mainHandler.post { scheduleListeningRestartIfEnabled() }
            },
        )
    }

    private fun handleShizukaIntent(intent: ShizukaIntent) {
        Log.i(Constants.LOG_TAG, "Intent: action=${intent.action} target='${intent.target}' provider=${intent.provider}")

        when (intent.action) {
            "OPEN"      -> AppLauncher.launch(applicationContext, intent.target)
            "WHATSAPP"  -> WhatsAppLauncher.send(applicationContext, intent.target, intent.message)
            "TYPE_TEXT" -> DeviceController.typeTextIntoFocusedField(this, intent.message)
            "SET_ALARM" -> DeviceController.setAlarm(applicationContext, intent.target, intent.message)
            "CALL"      -> DeviceController.makeCall(applicationContext, intent.target)
            "SEARCH"    -> DeviceController.searchWeb(applicationContext, intent.target)
            "CHAT"      -> { /* reply is the payload — spoken below */ }
            else        -> Log.w(Constants.LOG_TAG, "Unknown action from backend: ${intent.action}")
        }

        speakReply(intent.reply)
    }

    // ─── TTS playback ─────────────────────────────────────────────────────

    private fun speakReply(replyText: String) {
        if (replyText.isBlank() || isServiceTornDown) {
            isProcessingTranscript.set(false)
            scheduleListeningRestartIfEnabled()
            return
        }

        ApiClient.streamSpeech(
            text      = replyText,
            onSuccess = { response -> playStreamedSpeech(response) },
            onError   = { error ->
                Log.e(Constants.LOG_TAG, "TTS request failed", error)
                isProcessingTranscript.set(false)
                mainHandler.post { scheduleListeningRestartIfEnabled() }
            },
        )
    }

    private fun playStreamedSpeech(response: Response) {
        val tempFile = File(cacheDir, "shizuka_tts_${System.currentTimeMillis()}.mp3")

        // Gate the mic BEFORE any audio starts to ensure zero overlap
        isSpeaking = true
        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
        isListeningCycleActive = false

        // Buffer the stream to a temp file (MediaPlayer requires seekable source)
        try {
            response.use { r ->
                val body = r.body ?: throw IOException("Empty TTS body")
                FileOutputStream(tempFile).use { out -> body.byteStream().copyTo(out) }
            }
        } catch (e: IOException) {
            Log.e(Constants.LOG_TAG, "Failed to buffer TTS audio", e)
            tempFile.delete()
            onSpeechPlaybackFinished()
            return
        }

        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                )
                setDataSource(tempFile.absolutePath)
                setOnCompletionListener {
                    it.release()
                    mediaPlayer = null
                    tempFile.delete()
                    onSpeechPlaybackFinished()
                }
                setOnErrorListener { player, what, extra ->
                    Log.e(Constants.LOG_TAG, "MediaPlayer error what=$what extra=$extra")
                    player.release()
                    mediaPlayer = null
                    tempFile.delete()
                    onSpeechPlaybackFinished()
                    true
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Failed to start MediaPlayer", e)
            tempFile.delete()
            onSpeechPlaybackFinished()
        }
    }

    /**
     * Called after TTS finishes (success, error, or teardown).
     * Clears all processing flags and resumes the listening pipeline.
     */
    private fun onSpeechPlaybackFinished() {
        isSpeaking = false
        isProcessingTranscript.set(false)
        scheduleListeningRestartIfEnabled()
    }

    // ─── Foreground notification ───────────────────────────────────────────

    private fun startForegroundListeningNotification() {
        val notification = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(getString(R.string.notification_listening_title))
            .setContentText(getString(R.string.notification_listening_text))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setShowWhen(false)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    Constants.NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
                )
            } else {
                startForeground(Constants.NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Failed to start foreground notification", e)
        }
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Shizuka::BackgroundListeningWakeLock",
            ).apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 60 * 1000L)   // 10-hour cap
            }
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "Failed to acquire wake lock", e)
        }
    }
}
