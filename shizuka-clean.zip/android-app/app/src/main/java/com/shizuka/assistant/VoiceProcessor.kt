package com.shizuka.assistant

/**
 * Local, purely client-side transcript cleanup. Runs on every raw
 * [android.speech.SpeechRecognizer] result before it is ever sent to the
 * backend, so network latency/cost is never spent on garbled input.
 */
object VoiceProcessor {

    /**
     * Collapses immediately-repeated words caused by speech stutters, mic
     * echo, or noisy environments — e.g. "Shizuka open open chrome" becomes
     * "Shizuka open chrome", and "kholo kholo whatsapp" becomes
     * "kholo whatsapp". Case-insensitive and Unicode-aware so it also works
     * for Hindi/Devanagari and Hinglish transcripts.
     *
     * The regex matches a word, followed by one or more immediate repeats
     * of that exact same word (separated only by whitespace), and replaces
     * the whole run with a single instance of the word.
     */
    private val STUTTER_REGEX = Regex(
        pattern = "(?i)\\b(\\p{L}+)(?:\\s+\\1\\b)+",
    )

    private val MULTI_SPACE_REGEX = Regex("\\s{2,}")

    /**
     * Runs the full local cleanup pipeline on a raw transcript: trims
     * surrounding whitespace, collapses stuttered word repeats, and
     * normalizes internal whitespace runs down to single spaces.
     */
    fun cleanTranscript(rawTranscript: String): String {
        if (rawTranscript.isBlank()) {
            return ""
        }

        val deStuttered = STUTTER_REGEX.replace(rawTranscript.trim()) { matchResult ->
            matchResult.groupValues[1]
        }

        return MULTI_SPACE_REGEX.replace(deStuttered, " ").trim()
    }

    /**
     * Detects whether the transcript opens with the "Shizuka" wake word
     * (in English, Hindi, or common Hinglish spellings) and, if so, strips
     * it before the remaining command text is sent onward. Returns the
     * cleaned command text with the wake word removed; if no wake word is
     * present, returns the original text unchanged.
     */
    fun stripWakeWord(cleanedTranscript: String): String {
        val wakeWordRegex = Regex(
            pattern = "^(?i)\\s*(shizuka|shizu|शिज़ुका|शिजुका)[,.:!\\s-]*",
        )
        return wakeWordRegex.replace(cleanedTranscript, "").trim()
    }
}
