package com.shizuka.assistant

import android.content.Context
import android.content.Intent
import android.util.Log
import java.util.Locale

/**
 * Resolves a spoken app name to an installed package and launches it.
 * Three-tier resolution: known-alias map → exact package ID → fuzzy
 * label match against all installed launchable activities.
 */
object AppLauncher {

    private val KNOWN_PACKAGES: Map<String, String> = mapOf(
        // ── Browsers ──────────────────────────────────────────────────
        "chrome"            to "com.android.chrome",
        "google chrome"     to "com.android.chrome",
        "browser"           to "com.android.chrome",
        "firefox"           to "org.mozilla.firefox",
        "edge"              to "com.microsoft.emmx",
        "brave"             to "com.brave.browser",
        "opera"             to "com.opera.browser",
        "uc browser"        to "com.UCMobile.intl",

        // ── Messaging ─────────────────────────────────────────────────
        "whatsapp"          to "com.whatsapp",
        "whatsapp business" to "com.whatsapp.w4b",
        "telegram"          to "org.telegram.messenger",
        "signal"            to "org.thoughtcrime.securesms",
        "messenger"         to "com.facebook.orca",
        "sms"               to "com.google.android.apps.messaging",
        "messages"          to "com.google.android.apps.messaging",

        // ── Social ────────────────────────────────────────────────────
        "instagram"         to "com.instagram.android",
        "facebook"          to "com.facebook.katana",
        "twitter"           to "com.twitter.android",
        "x"                 to "com.twitter.android",
        "snapchat"          to "com.snapchat.android",
        "linkedin"          to "com.linkedin.android",
        "reddit"            to "com.reddit.frontpage",
        "pinterest"         to "com.pinterest",
        "threads"           to "com.instagram.barcelona",
        "shareChat"         to "in.sharechat.app",
        "moj"               to "in.mohalla.app",

        // ── Google apps ───────────────────────────────────────────────
        "youtube"           to "com.google.android.youtube",
        "gmail"             to "com.google.android.gm",
        "email"             to "com.google.android.gm",
        "maps"              to "com.google.android.apps.maps",
        "google maps"       to "com.google.android.apps.maps",
        "drive"             to "com.google.android.apps.docs",
        "photos"            to "com.google.android.apps.photos",
        "gallery"           to "com.google.android.apps.photos",
        "calendar"          to "com.google.android.calendar",
        "contacts"          to "com.google.android.contacts",
        "meet"              to "com.google.android.apps.tachyon",
        "google meet"       to "com.google.android.apps.tachyon",
        "keep"              to "com.google.android.keep",
        "notes"             to "com.google.android.keep",
        "translate"         to "com.google.android.apps.translate",
        "play store"        to "com.android.vending",
        "playstore"         to "com.android.vending",
        "play"              to "com.android.vending",
        "fit"               to "com.google.android.apps.fitness",
        "google fit"        to "com.google.android.apps.fitness",
        "pay"               to "com.google.android.apps.nbu.paisa.user",
        "google pay"        to "com.google.android.apps.nbu.paisa.user",
        "gpay"              to "com.google.android.apps.nbu.paisa.user",

        // ── System ───────────────────────────────────────────────────
        "settings"          to "com.android.settings",
        "phone"             to "com.google.android.dialer",
        "dialer"            to "com.google.android.dialer",
        "call"              to "com.google.android.dialer",
        "camera"            to "com.android.camera2",
        "calculator"        to "com.google.android.calculator",
        "clock"             to "com.google.android.deskclock",
        "alarm"             to "com.google.android.deskclock",
        "files"             to "com.google.android.apps.nbu.files",
        "file manager"      to "com.google.android.apps.nbu.files",

        // ── Entertainment ─────────────────────────────────────────────
        "spotify"           to "com.spotify.music",
        "music"             to "com.spotify.music",
        "netflix"           to "com.netflix.mediaclient",
        "hotstar"           to "in.startv.hotstar",
        "disney hotstar"    to "in.startv.hotstar",
        "jio cinema"        to "com.jio.jiocinema",
        "jioCinema"         to "com.jio.jiocinema",
        "amazon prime"      to "com.amazon.avod.thirdpartyclient",
        "prime video"       to "com.amazon.avod.thirdpartyclient",
        "mx player"         to "com.mxtech.videoplayer.ad",
        "vlc"               to "org.videolan.vlc",
        "youtube music"     to "com.google.android.apps.youtube.music",
        "gaana"             to "com.gaana",
        "jiosaavn"          to "com.jio.media.jiobeats",
        "wynk"              to "com.bsbportal.music",

        // ── Shopping / Finance ────────────────────────────────────────
        "amazon"            to "in.amazon.mShop.android.shopping",
        "flipkart"          to "com.flipkart.android",
        "meesho"            to "com.meesho.supply",
        "nykaa"             to "com.fsn.nykaa",
        "myntra"            to "com.myntra.android",
        "paytm"             to "net.one97.paytm",
        "phonepe"           to "com.phonepe.app",
        "cred"              to "com.dreamplug.androidapp",
        "groww"             to "com.nextbillion.groww",
        "zerodha"           to "com.zerodha.kite3",
        "upstox"            to "in.upstox.app",

        // ── Transport / Food ──────────────────────────────────────────
        "uber"              to "com.ubercab",
        "ola"               to "com.olacabs.customer",
        "rapido"            to "com.rapido.passenger",
        "zomato"            to "com.application.zomato",
        "swiggy"            to "in.swiggy.android",
        "dunzo"             to "com.dunzo.user",
        "blinkit"           to "com.grofers.customerapp",

        // ── Productivity / Communication ──────────────────────────────
        "zoom"              to "us.zoom.videomeetings",
        "teams"             to "com.microsoft.teams",
        "microsoft teams"   to "com.microsoft.teams",
        "slack"             to "com.Slack",
        "notion"            to "notion.id",
        "trello"            to "com.trello",
        "word"              to "com.microsoft.office.word",
        "excel"             to "com.microsoft.office.excel",
        "powerpoint"        to "com.microsoft.office.powerpoint",
        "outlook"           to "com.microsoft.office.outlook",
        "onedrive"          to "com.microsoft.skydrive",
        "dropbox"           to "com.dropbox.android",
    )

    fun launch(context: Context, rawTarget: String): Boolean {
        val normalized = rawTarget.trim().lowercase(Locale.ROOT)
        if (normalized.isEmpty()) {
            Log.w(Constants.LOG_TAG, "AppLauncher.launch: empty target")
            return false
        }

        // 1. Known alias map
        KNOWN_PACKAGES[normalized]?.let { pkg ->
            if (launchPackage(context, pkg)) return true
        }

        // 2. Exact package ID
        if (launchPackage(context, rawTarget.trim())) return true

        // 3. Fuzzy match against installed launchable activity labels
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolvedActivities = context.packageManager.queryIntentActivities(launcherIntent, 0)

        for (resolveInfo in resolvedActivities) {
            val label = resolveInfo.loadLabel(context.packageManager).toString().lowercase(Locale.ROOT)
            if (label == normalized || label.contains(normalized) || normalized.contains(label)) {
                if (launchPackage(context, resolveInfo.activityInfo.packageName)) return true
            }
        }

        Log.w(Constants.LOG_TAG, "AppLauncher.launch: could not resolve target='$rawTarget'")
        return false
    }

    private fun launchPackage(context: Context, packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            context.startActivity(intent)
            Log.i(Constants.LOG_TAG, "AppLauncher: launched $packageName")
            true
        } catch (e: Exception) {
            Log.e(Constants.LOG_TAG, "AppLauncher: failed to launch $packageName", e)
            false
        }
    }
}
