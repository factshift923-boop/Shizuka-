package com.shizuka.assistant

object Constants {

    // ─── Backend connection ────────────────────────────────────────────────
    /** Default backend URL — overridden at runtime by PREF_BACKEND_URL. */
    const val DEFAULT_BACKEND_BASE_URL: String = "https://your-shizuka-backend.example.com/api"

    /**
     * Shared secret header sent as `x-shizuka-api-key` on every
     * `/api/chat` and `/api/tts` call. Must match SHIZUKA_API_KEY on the
     * backend. Leave blank if the backend has no key configured (dev only).
     * Stored via PREF_API_KEY, falls back to this empty default.
     */
    const val API_KEY: String = ""

    // ─── SharedPreferences keys ───────────────────────────────────────────
    const val PREFS_NAME: String = "shizuka_prefs"

    /** Permission toggle states (synced from live system state by MainActivity). */
    const val PREF_ACCESSIBILITY_ENABLED: String = "pref_accessibility_enabled"
    const val PREF_MIC_ENABLED: String          = "pref_mic_enabled"
    const val PREF_OVERLAY_ENABLED: String       = "pref_overlay_enabled"

    /** Settings panel — user-configurable fields. */
    const val PREF_BACKEND_URL: String     = "pref_backend_url"
    const val PREF_API_KEY: String         = "pref_api_key"
    const val PREF_GEMINI_API_KEY: String  = "pref_gemini_api_key"  // stored locally for reference
    const val PREF_GROQ_API_KEY: String    = "pref_groq_api_key"    // stored locally for reference
    const val PREF_USER_NAME: String       = "pref_user_name"
    const val PREF_LANGUAGE: String        = "pref_language"        // auto|english|hinglish|hindi

    // ─── Foreground service notification ─────────────────────────────────
    const val NOTIFICATION_CHANNEL_ID: String = "shizuka_listening_channel"
    const val NOTIFICATION_ID: Int = 4201

    // ─── Voice pipeline timing ────────────────────────────────────────────
    /** Double-press window for the volume-key hotkey (ms). */
    const val DOUBLE_PRESS_WINDOW_MS: Long = 600L

    /** Delay before restarting the recognition cycle after a result/error (ms). */
    const val LISTEN_RESTART_DELAY_MS: Long = 450L

    /** How long to keep the audio streams muted when SpeechRecognizer starts (ms). */
    const val BEEP_MUTE_DURATION_MS: Long = 700L

    const val LOG_TAG: String = "Shizuka"
}
