package com.shizuka.assistant

import android.content.SharedPreferences
import android.util.Log
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Parsed result of `POST /api/chat`. Mirrors the backend intent contract
 * including the expanded action set (OPEN, WHATSAPP, CHAT, TYPE_TEXT,
 * SET_ALARM, CALL, SEARCH).
 */
data class ShizukaIntent(
    val action: String,   // OPEN | WHATSAPP | CHAT | TYPE_TEXT | SET_ALARM | CALL | SEARCH
    val target: String,
    val message: String,
    val reply: String,
    val provider: String,
)

data class ChatTurn(val role: String, val content: String)

/**
 * Singleton HTTP client for the Shizuka backend. Call [configure] once on
 * startup (and again whenever settings change) so all subsequent requests
 * use the latest backend URL, API key, and session context.
 *
 * Thread-safe: all mutable config fields are @Volatile; OkHttp's dispatcher
 * and its underlying connection pool are thread-safe by design.
 */
object ApiClient {

    private const val JSON_MEDIA_TYPE = "application/json; charset=utf-8"

    // ─── Dynamic session config (populated by configure()) ───────────────

    @Volatile private var baseUrl: String = Constants.DEFAULT_BACKEND_BASE_URL
    @Volatile private var apiKey: String  = Constants.API_KEY
    @Volatile private var language: String = "auto"
    @Volatile private var userName: String = ""

    private val chatEndpoint get() = "${baseUrl.trimEnd('/')}/chat"
    private val ttsEndpoint  get() = "${baseUrl.trimEnd('/')}/tts"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        // No interceptors that send data to third-party services — all traffic
        // goes exclusively to the user's private backend.
        .build()

    /**
     * Reads the latest user settings from [prefs] and applies them to all
     * subsequent requests. Must be called after the user saves new settings
     * and on every service start.
     */
    fun configure(prefs: SharedPreferences) {
        val rawUrl = prefs.getString(Constants.PREF_BACKEND_URL, "")?.trim() ?: ""
        baseUrl   = rawUrl.ifEmpty { Constants.DEFAULT_BACKEND_BASE_URL }
        apiKey    = prefs.getString(Constants.PREF_API_KEY, Constants.API_KEY)?.trim() ?: Constants.API_KEY
        language  = prefs.getString(Constants.PREF_LANGUAGE, "auto")?.trim() ?: "auto"
        userName  = prefs.getString(Constants.PREF_USER_NAME, "")?.trim() ?: ""
        Log.i(Constants.LOG_TAG, "ApiClient configured — baseUrl=${baseUrl} language=${language} user=${userName.ifEmpty { "(Boss)" }}")
    }

    /** Cancels every in-flight request. Called from teardownEverything(). */
    fun cancelAllRequests() {
        client.dispatcher.cancelAll()
    }

    /**
     * Sends [message] + optional [history] to `POST /api/chat`.
     * Language and user name from the latest [configure] call are
     * automatically included for personalised responses. Both callbacks
     * fire on a background thread.
     */
    fun sendChatMessage(
        message: String,
        history: List<ChatTurn> = emptyList(),
        onSuccess: (ShizukaIntent) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        val historyArray = JSONArray().also { arr ->
            history.forEach { turn ->
                arr.put(JSONObject().apply {
                    put("role", turn.role)
                    put("content", turn.content)
                })
            }
        }

        val bodyJson = JSONObject().apply {
            put("message", message)
            put("history", historyArray)
            put("language", language)
            if (userName.isNotEmpty()) put("userName", userName)
        }

        val request = buildRequest(chatEndpoint, bodyJson.toString())

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(Constants.LOG_TAG, "Chat request failed", e)
                onError(e)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { httpResponse ->
                    try {
                        if (!httpResponse.isSuccessful) {
                            throw IOException("Chat request returned HTTP ${httpResponse.code}")
                        }

                        val rawBody = httpResponse.body?.string()
                            ?: throw IOException("Chat response body was empty")

                        val json = JSONObject(rawBody)

                        val intent = ShizukaIntent(
                            action   = json.getString("action"),
                            target   = json.optString("target", ""),
                            message  = json.optString("message", ""),
                            reply    = json.getString("reply"),
                            provider = json.optString("provider", "unknown"),
                        )

                        onSuccess(intent)
                    } catch (e: Exception) {
                        Log.e(Constants.LOG_TAG, "Failed to parse chat response", e)
                        onError(e)
                    }
                }
            }
        })
    }

    /**
     * Sends [text] to `POST /api/tts` and delivers the raw
     * [Response] (MP3 stream) to [onSuccess]. The caller owns the
     * response and must close it after playback.
     */
    fun streamSpeech(
        text: String,
        onSuccess: (Response) -> Unit,
        onError: (Exception) -> Unit,
    ) {
        val bodyJson = JSONObject().apply { put("text", text) }
        val request  = buildRequest(ttsEndpoint, bodyJson.toString())

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(Constants.LOG_TAG, "TTS request failed", e)
                onError(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    response.close()
                    onError(IOException("TTS request returned HTTP ${response.code}"))
                    return
                }
                onSuccess(response)
            }
        })
    }

    // ─── Private helpers ──────────────────────────────────────────────────

    private fun buildRequest(url: String, jsonBody: String): Request {
        val body = jsonBody.toRequestBody(JSON_MEDIA_TYPE.toMediaType())
        return Request.Builder()
            .url(url)
            .post(body)
            .header("Content-Type", "application/json")
            .also { builder ->
                if (apiKey.isNotEmpty()) {
                    builder.header("x-shizuka-api-key", apiKey)
                }
            }
            .build()
    }
}
