package com.shizuka.assistant

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

/**
 * Settings dashboard — opened by tapping the ⚙️ gear icon in [MainActivity].
 *
 * Persists to [SharedPreferences] (private, inaccessible to other apps):
 *  • Backend URL     (PREF_BACKEND_URL)
 *  • Gemini API Key  (PREF_GEMINI_API_KEY — stored locally, reference only)
 *  • Groq API Key    (PREF_GROQ_API_KEY   — stored locally, reference only)
 *  • User Name       (PREF_USER_NAME)      — sent to backend for personalisation
 *  • Language        (PREF_LANGUAGE)       — sent to backend for language selection
 *
 * On save, [ApiClient.configure] is called immediately so the running
 * voice service picks up the new settings without a restart.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private lateinit var etBackendUrl: TextInputEditText
    private lateinit var etBackendApiKey: TextInputEditText
    private lateinit var etGeminiKey: TextInputEditText
    private lateinit var etGroqKey: TextInputEditText
    private lateinit var etUserName: TextInputEditText
    private lateinit var spinnerLanguage: Spinner

    /** Parallel arrays: display labels ↔ internal pref values. */
    private val languageLabels by lazy { resources.getStringArray(R.array.language_options).toList() }
    private val languageValues by lazy { resources.getStringArray(R.array.language_values).toList() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences(Constants.PREFS_NAME, Context.MODE_PRIVATE)

        // Toolbar back button
        val toolbar = findViewById<Toolbar>(R.id.toolbarSettings)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        etBackendUrl    = findViewById(R.id.etBackendUrl)
        etBackendApiKey = findViewById(R.id.etBackendApiKey)
        etGeminiKey     = findViewById(R.id.etGeminiKey)
        etGroqKey       = findViewById(R.id.etGroqKey)
        etUserName      = findViewById(R.id.etUserName)
        spinnerLanguage = findViewById(R.id.spinnerLanguage)

        setupLanguageSpinner()
        loadCurrentSettings()

        findViewById<MaterialButton>(R.id.btnSaveSettings).setOnClickListener {
            saveSettings()
        }
    }

    // ─── Spinner ─────────────────────────────────────────────────────────

    private fun setupLanguageSpinner() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            languageLabels,
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        spinnerLanguage.adapter = adapter
    }

    // ─── Load ─────────────────────────────────────────────────────────────

    private fun loadCurrentSettings() {
        etBackendUrl.setText(prefs.getString(Constants.PREF_BACKEND_URL, "") ?: "")
        etBackendApiKey.setText(prefs.getString(Constants.PREF_API_KEY, "") ?: "")
        etGeminiKey.setText(prefs.getString(Constants.PREF_GEMINI_API_KEY, "") ?: "")
        etGroqKey.setText(prefs.getString(Constants.PREF_GROQ_API_KEY, "") ?: "")
        etUserName.setText(prefs.getString(Constants.PREF_USER_NAME, "") ?: "")

        val savedLanguage = prefs.getString(Constants.PREF_LANGUAGE, "auto") ?: "auto"
        val idx = languageValues.indexOf(savedLanguage).coerceAtLeast(0)
        spinnerLanguage.setSelection(idx)
    }

    // ─── Save ─────────────────────────────────────────────────────────────

    private fun saveSettings() {
        val backendUrl    = etBackendUrl.text?.toString()?.trim() ?: ""
        val backendApiKey = etBackendApiKey.text?.toString()?.trim() ?: ""
        val geminiKey     = etGeminiKey.text?.toString()?.trim() ?: ""
        val groqKey       = etGroqKey.text?.toString()?.trim() ?: ""
        val userName      = etUserName.text?.toString()?.trim() ?: ""
        val langIdx       = spinnerLanguage.selectedItemPosition.coerceIn(0, languageValues.lastIndex)
        val language      = languageValues[langIdx]

        prefs.edit()
            .putString(Constants.PREF_BACKEND_URL,    backendUrl)
            .putString(Constants.PREF_API_KEY,        backendApiKey)
            .putString(Constants.PREF_GEMINI_API_KEY, geminiKey)
            .putString(Constants.PREF_GROQ_API_KEY,   groqKey)
            .putString(Constants.PREF_USER_NAME,      userName)
            .putString(Constants.PREF_LANGUAGE,       language)
            .apply()

        // Immediately reconfigure the HTTP client so the running service
        // picks up the new backend URL and session context without needing
        // a restart.
        ApiClient.configure(prefs)

        Toast.makeText(this, getString(R.string.settings_saved_toast), Toast.LENGTH_SHORT).show()
        finish()
    }
}
