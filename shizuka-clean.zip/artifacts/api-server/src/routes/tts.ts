import { Router, type IRouter } from "express";
import { synthesizeSpeech } from "../lib/tts";
import { shizukaGuard } from "../middlewares/shizukaGuard";

const router: IRouter = Router();

router.use("/tts", shizukaGuard);

/**
 * POST /api/tts
 *
 * Body: { "text": string }
 * Response: raw `audio/mpeg` bytes streamed directly to the client as they
 * arrive from the Edge neural TTS engine, for the lowest possible
 * time-to-first-audio-byte. The voice is auto-selected (Hindi vs.
 * English/Hinglish) based on script detection, and a fixed +15Hz pitch
 * lift is always applied for Shizuka's signature voice texture.
 */
router.post("/tts", async (req, res): Promise<void> => {
  const { text } = req.body ?? {};

  if (typeof text !== "string" || text.trim().length === 0) {
    res.status(400).json({ error: "Field 'text' is required and must be a non-empty string" });
    return;
  }

  try {
    const { audioStream, voice, contentType } = await synthesizeSpeech(text);

    req.log.info({ voice, chars: text.length }, "Streaming TTS synthesis");

    res.status(200);
    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Shizuka-Voice", voice);

    audioStream.on("error", (streamErr) => {
      req.log.error({ err: streamErr }, "TTS audio stream errored mid-flight");
      if (!res.headersSent) {
        res.status(502).json({ error: "TTS synthesis failed" });
      } else {
        res.end();
      }
    });

    audioStream.pipe(res);
  } catch (err) {
    req.log.error({ err }, "Failed to start TTS synthesis");
    res.status(502).json({ error: "TTS synthesis failed" });
  }
});

export default router;
